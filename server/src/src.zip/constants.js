exports.COOKIE_SESSION_NAME = 'user';
