exports.PORT = 5000;
exports.SALT_ROUNDS = 10;
exports.SECRET = '23eb16ae42981b643b18d7b9bc848ddf'